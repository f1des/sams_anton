﻿/*
 Задача: Написать консольное приложение, которое проверяет принадлежность точки заштрихованной области.
Пользователь вводит координаты точки (x; y) и выбирает букву графика (a-к). В консоли должно высветиться сообщение: «Точка [(x; y)] принадлежит фигуре [г]»
 Дата: 07.11.2016
 Автор: Самсонов А.В
 * */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task0_1 // Задание 0_1
{
    class Program
    {
        const double r_max = 1.0; // Максимальное значения радиуса точки

        static void Main(string[] args)
        {
            Console.WriteLine("Задание 0_1.\nВведите координаты точки (x, y):");
            Console.Write("x = ");
            double x = double.Parse(Console.ReadLine());
            Console.Write("y = ");
            double y = double.Parse(Console.ReadLine());
            Console.WriteLine("Получилась точка с координатами (" + x + ";" + y + ")\nВыберите фигуру (а-к):");
            string figure = Console.ReadLine();
            switch (figure) // Выбираем нужную нам фигуру
            {
                case "а":
                    check_a(x, y);
                    break;
                case "б":
                    check_b(x, y);
                    break;
                case "в":
                    check_c(x, y);
                    break;
                case "г":
                    check_d(x, y);
                    break;
                case "д":
                    check_e(x, y);
                    break;
                case "е":
                    check_f(x, y);
                    break;
                case "ж":
                    check_g(x, y);
                    break;
                case "з":
                    check_i(x, y);
                    break;
                case "и":
                    check_k(x, y);
                    break;
                case "к":
                    check_l(x, y);
                    break;
                default:
                    Console.WriteLine("Фигуры под такой буквой не существует.");
                    break;
            }
            Console.ReadKey();
        }

        static void check_a(double x, double y) // Статическая функция для фигуры "а"
        {
            if (x * x + y * y <= r_max * r_max)  // Условие принадлежности точки к фигуре
                Console.WriteLine("Точка(" + x + ";" + y + ") принадлежит фигуре а");
            else
                Console.WriteLine("Точка(" + x + ";" + y + ") не принадлежит фигуре а");
            return;
        }

        static void check_b(double x, double y) // Статическая функция для фигуры "б"
        {
            if ((x * x + y * y <= r_max * r_max) & (x * x + y * y >= (r_max / 2) * (r_max / 2)))
                Console.WriteLine("Точка(" + x + ";" + y + ") принадлежит фигуре б");
            else
                Console.WriteLine("Точка(" + x + ";" + y + ") не принадлежит фигуре б");
            return;
        }

        static void check_c(double x, double y) // Статическая функция для фигуры "в"
        {
            if ((x <= r_max) & (x >= -r_max) & (y <= r_max) & (y >= -r_max))
                Console.WriteLine("Точка(" + x + ";" + y + ") принадлежит фигуре в");
            else
                Console.WriteLine("Точка(" + x + ";" + y + ") не принадлежит фигуре в");
            return;
        }

        static void check_d(double x, double y) // Статическая функция для фигуры "г"
        {
            if ((x + y >= -r_max) & (x + y <= r_max) & (y - x <= r_max) & (y - x >= -r_max))
                Console.WriteLine("Точка(" + x + ";" + y + ") принадлежит фигуре г");
            else
                Console.WriteLine("Точка(" + x + ";" + y + ") не принадлежит фигуре г");
            return;
        }

        static void check_e(double x, double y) // Статическая функция для фигуры "д"
        {
            if ((y >= 2 * x - r_max) & (y >= -2 * x - r_max) & (y <= 2 * x + r_max) & (y <= -2 * x + r_max))
                Console.WriteLine("Точка(" + x + ";" + y + ") принадлежит фигуре д");
            else
                Console.WriteLine("Точка(" + x + ";" + y + ") не принадлежит фигуре д");
            return;
        }

        static void check_f(double x, double y) // Статическая функция для фигуры "е"
        {
            if ((2 * y - x <= 2 * r_max) & (2 * y + x >= -2 * r_max) & (x <= Math.Sqrt(r_max * r_max - y * y)))
                Console.WriteLine("Точка(" + x + ";" + y + ") принадлежит фигуре е");
            else
                Console.WriteLine("Точка(" + x + ";" + y + ") не принадлежит фигуре е");
            return;
        }

        static void check_g(double x, double y) // Статическая функция для фигуры "ж"
        {
            if ((y >= -1) & (y <= -2 * (x - r_max) & (y <= 2 * (x + r_max))))
                Console.WriteLine("Точка(" + x + ";" + y + ") принадлежит фигуре ж");
            else
                Console.WriteLine("Точка(" + x + ";" + y + ") не принадлежит фигуре ж");
            return;
        }

        static void check_i(double x, double y) // Статическая функция для фигуры "з"
        {
            if ((y >= -3 * r_max) & (x >= -r_max) & (x <= r_max) & (y <= Math.Abs(x)))
                Console.WriteLine("Точка(" + x + ";" + y + ") принадлежит фигуре з");
            else
                Console.WriteLine("Точка(" + x + ";" + y + ") не принадлежит фигуре з");
            return;
        }

        static void check_k(double x, double y) // Статическая функция для фигуры "и"
        {
            if (((y >= 0) & (y >= (x - r_max) / 3) & (y <= 2 * x + 3)) || ((y >= 0) & (y <= 2 * x + 3) & (y <= -x)))
                Console.WriteLine("Точка(" + x + ";" + y + ") принадлежит фигуре и");
            else
                Console.WriteLine("Точка(" + x + ";" + y + ") не принадлежит фигуре и");
            return;
        }

        static void check_l(double x, double y) // Статическая функция для фигуры "к"
        {
            if ((y >= r_max) | (y >= Math.Abs(x)))
                Console.WriteLine("Точка(" + x + ";" + y + ") принадлежит фигуре к");
            else
                Console.WriteLine("Точка(" + x + ";" + y + ") не принадлежит фигуре к");
            return;
        }
    }
}

