﻿/*
 Задача: Дано действительное число h. Выяснить, имеет ли уранение a*x^2 + b*x + c = 0 действительные корни, если 
 a = sqrt[(abc(sin(8*h))+17)]/sqr([1-sin(4*h*cos(sqr(h)+18))]), b = 1 - sqrt[3/(3+abc(tg(a*h^2))-sin(a*h))], c = a*sqr(h)*sin(b*h)+b*h^3 * cos(a*h). 
 Если действительные корни существуют, то найти их. В противном случае ответом должно служить сообщение, что действительных корней нет.
 Дата: 08.11.2016
 Автор: Самсонов А.В
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task0_2 // Задание 0_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Задание0_2.\nВведите h = ");
            double h = double.Parse(Console.ReadLine());
            Console.WriteLine("Значение     h = " + h);   
            double a = Calculatea(h);
            Console.WriteLine("Значение     a = " + a);
            double b = Calculateb(h, a);
            Console.WriteLine("Значение     b = " + b);
            double c = Calculatec(h, a, b);
            Console.WriteLine("Значение     c = " + c);
            double disсr = Discr(a, b, c);
            Console.WriteLine("Дискриминант D = " + disсr);
            if (disсr > 0)
            {
                Console.WriteLine("Имеется два корня:");
                double x1 = (-b + Math.Sqrt(disсr)) / 2 * a;
                double x2 = (-b - Math.Sqrt(disсr)) / 2 * a;
                Console.WriteLine("x1=" + x1);
                Console.WriteLine("x2=" + x2);
                Console.ReadLine();
                return;
            }
            if (disсr == 0) 
            {
                Console.WriteLine("Имеется имеется один корень:");
                double x = (-b + Math.Sqrt(disсr)) / 2 * a;
                Console.WriteLine("x=" + x);
                Console.ReadLine();
                return;
            }
            Console.WriteLine("Уравнение не имеет действительных корней");
            Console.ReadLine();
            return;
        }
        static double Calculatea(double h)  //Статическая функция вычисляющая значения под "а"
        {
            double num = Math.Abs(Math.Sin(8 * h)) + 17;                                //Числитель
            double denom = Math.Pow((1 - Math.Sin(4 * h) * Math.Cos(h * h + 18)), 2);   //Знаменатель
            return Math.Sqrt(num / denom);                                              //Возвращаем квадратный корень дроби
        }
        static double Calculateb(double h, double a) //Статическая функция вычисляющая значения под "b"
        {
            double denom = 3 + Math.Abs(Math.Tan(a * h * h) - Math.Sin(a * h)); //Знаменатель
            return 1 - Math.Sqrt(3 / denom);
        }
        static double Calculatec(double h, double a, double b)  //Статическая функция вычисляющая значения под "c"
        {
            return a * h * h * Math.Sin(b * h) + b * h * h * h * Math.Cos(a * h);
        }
        static double Discr(double a, double b, double c)   //Статическая функция вычисляющая значения под "D"
        {
            return b * b - 4 * a * c;
        }
    }
}

